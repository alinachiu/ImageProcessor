package utils;

import java.io.File;
import java.io.IOException;
import javax.swing.filechooser.FileSystemView;

/**
 * Represents a class that restricts a user's ability to view files to a set of files within a root
 * directory only.
 */
public class DirectoryRestrictedFileSystemView extends FileSystemView {

  private final File[] rootDirectories;

  /**
   * Constructs an {@code DirectoryRestrictedFileSystemView} object with a given file as the root
   * directory.
   *
   * @param rootDirectory the root directory file
   * @throws IllegalArgumentException if the given root directory is null or nonexistent
   */
  public DirectoryRestrictedFileSystemView(File rootDirectory) {
    if (rootDirectory == null || !rootDirectory.exists()) {
      throw new IllegalArgumentException("Root directory is null or doesn't exist");
    }
    this.rootDirectories = new File[]{rootDirectory};
  }

  @Override
  public File createNewFolder(File containingDir) throws IOException {
    throw new UnsupportedOperationException("Unable to create directory");
  }

  @Override
  public File[] getRoots() {
    return rootDirectories;
  }

  @Override
  public boolean isRoot(File file) {
    if (file == null || !file.exists()) {
      throw new IllegalArgumentException("File is null or doesn't exist");
    }
    for (File root : rootDirectories) {
      if (root.equals(file)) {
        return true;
      }
    }
    return false;
  }
}
